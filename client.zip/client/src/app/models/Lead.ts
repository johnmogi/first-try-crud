export class LeadModel {
    public constructor(
      public _ID?: String,
      public name?: String,
      public phone?: String,
      public mail?: string,
    ) {}
  }