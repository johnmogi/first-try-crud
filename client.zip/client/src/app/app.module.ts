import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { MainComponent } from './layout/main/main.component';
import { HeaderComponent } from './layout/header/header.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { FooterComponent } from './layout/footer/footer.component';

import {CardModule} from 'primeng/card';
import {AccordionModule} from 'primeng/accordion';
import { HomeComponent } from './pages/home/home.component';
import { ApplyComponent } from './pages/apply/apply.component';
import { LeadsComponent } from './pages/admin/leads/leads.component';
import { LeadDetailComponent } from './pages/admin/lead-detail/lead-detail.component';  
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    MainComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    HomeComponent,
    ApplyComponent,
    LeadsComponent,
    LeadDetailComponent, 
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    AccordionModule,
    CardModule
  ],
  providers: [],
  bootstrap: [MainComponent]
})
export class AppModule { }
