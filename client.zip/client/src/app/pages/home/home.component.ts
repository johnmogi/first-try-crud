import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { LeadsService } from 'src/app/leads.service';
import { LeadModel } from 'src/app/models/lead';
const port = 3000;
const address = `http://localhost:${port}/api/leads/`
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  //  public leads: LeadModel[]  =[];
   public leads =[];
 
  
  constructor(public _leadService = LeadsService) { }
  
  ngOnInit(): void {
    this.leads = this._leadService.

    // .subscribe(Response => {

    //   this.leads.push(Response)

    //   console.log(this.leads);
    // })
  

}
