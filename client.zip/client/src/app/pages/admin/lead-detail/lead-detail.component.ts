import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lead-detail',
  templateUrl: './lead-detail.component.html',
  styleUrls: ['./lead-detail.component.scss']
})
export class LeadDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
