import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LeadModel } from './models/lead';


@Injectable({
  providedIn: 'root'
})

const port = 3000;
export class LeadsService {
  public api = `http://localhost:${port}/api/leads/`;
  constructor(private http: HttpClient) {}

  public getAllLeads(): Observable<LeadModel[]> {
    return this.http.get<LeadModel[]>(this.api);
  }

}
